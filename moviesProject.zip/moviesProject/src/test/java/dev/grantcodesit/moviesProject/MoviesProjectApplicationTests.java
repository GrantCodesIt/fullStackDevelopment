package dev.grantcodesit.moviesProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviesProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
